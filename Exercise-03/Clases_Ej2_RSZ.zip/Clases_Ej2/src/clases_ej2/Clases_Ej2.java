/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package clases_ej2;
//importar Scanner
import java.util.Scanner;
/**
 *
 * @author alumno
 */
public class Clases_Ej2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //variable para guardar la longitud del array
        int longitud;
        //crear un objeto de la clase Scanner
        Scanner teclado = new Scanner(System.in);
        //pedir la longitud del array
        System.out.println("Introduce la longitud del array: ");
        longitud = teclado.nextInt();
        //crear un array de objetos de la clase Persona
        Persona[] vector = new Persona[longitud];
        //rellenar el vector con el método llenarArrayPersonas() de la clase ArrayPersonas
        ArrayPersonas.llenarArrayPersonas(vector);
        //imprimir el vector con el método visualizarArrayPersonas() de la clase ArrayPersonas
        ArrayPersonas.visualizarArrayPersonas(vector);
        







    }
    
}
