/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
import java.util.Scanner;
import java.util.List;
import java.util.ArrayList;
/**
 *
 * @author manana
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //generamos un inventario (lista de productos)
        Inventario inventario = new Inventario();
        inventario.generarInventario();
        
        //menú con 4 opciones: añadir producto, vender producto, mostrar productos y salir
        Scanner sc = new Scanner(System.in);
        int opcion;
        do {
            System.out.println("1. Añadir producto");
            System.out.println("2. Vender producto");
            System.out.println("3. Mostrar productos");
            System.out.println("4. Salir");
            System.out.println("Elige una opción: ");
            opcion = sc.nextInt();
            sc.nextLine();
            
            
            
            switch (opcion) {
                case 1:
                    //añadir producto
                    
                    inventario.añadirProducto();
                    break;
                case 2:
                    //vender producto
                    
                    inventario.venderProducto();
                    break;
                case 3:
                    //mostrar productos
                    inventario.mostrarInventario();
                    break;
                case 4:
                    //salir
                    System.out.println("Hasta pronto!");
                    break;
                default:
                    System.out.println("Opción incorrecta");
            }
        } while (opcion != 4);


    }
    
}
