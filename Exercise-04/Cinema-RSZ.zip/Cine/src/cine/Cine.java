/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package cine;
//importamos scanner
import java.util.Scanner;
//importamos random
import java.util.Random;

/**
 *
 * @author alumno
 */
public class Cine {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
            // crear una matriz de 5 filas y 10 columnas que representa los asientos de un cine
            int filas = 5;
            int columnas = 10;
            int[][] array = new int[filas][columnas];
            // llenamos la matriz de ceros
            for (int i = 0; i < array.length; i++) {
                for (int j = 0; j < array[i].length; j++) {
                    array[i][j] = 0;
                }
            }
            //-----------------------------------------------------------------------------
            // Para simular asientos ya ocupados, llenamos la matriz con números aleatorios entre 0 y 1
            Random aleatorio = new Random();
            for (int i = 0; i < array.length; i++) {
                for (int j = 0; j < array[i].length; j++) {
                    array[i][j] = aleatorio.nextInt(2);
                }
            }
             // imprimimos la matriz añadiendo una fila con los índices de las columnas y una columna con los índices de las filas. Si el valor es 1, se imprime una X
             System.out.println("Los asientos libres se representan con un 0 y los ocupados con una X.");
             System.out.println();
             System.out.print("\t");
             for (int i = 0; i < array[0].length; i++) {
                 System.out.print(i + 1 + "\t"); //ponemos i+1 para que los índices empiecen en 1
             }
             System.out.println();
             for (int i = 0; i < array.length; i++) {
                 System.out.print(i + 1 + "\t"); //ponemos i+1 para que los índices empiecen en 1
                 for (int j = 0; j < array[i].length; j++) {
                     if (array[i][j] == 0) {
                         System.out.print("0\t");
                     } else {
                         System.out.print("X\t");
                     }
                 }
                 System.out.println();
             }
            // creamos un menú que permita al usuario elegir entre las siguientes opciones:
            // 1. comprar entrada
            // 2. ver asientos
            // 3. salir
            Scanner sc = new Scanner(System.in);
            int opcion;
            do {
                System.out.println("1. Comprar entrada");
                System.out.println("2. Ver asientos");
                System.out.println("3. Salir");
                opcion = sc.nextInt();
                switch (opcion) {
                    case 1:
                        // pedimos al usuario que introduzca la fila y la columna del asiento que quiere reservar
                       
                        System.out.println();
                        System.out.println("Introduzca la fila del asiento que quiere reservar:");
                        int fila = sc.nextInt();
                        System.out.println("Introduzca la columna del asiento que quiere reservar:");
                        int columna = sc.nextInt();
                        // comprobamos que el asiento está libre y lo reservamos asignándole el valor 1
                        if (array[fila-1][columna-1] == 0) { //ponemos fila-1 y columna-1 porque los índices empiezan en 0, pero el usuario los introduce empezando en 1
                            array[fila-1][columna-1] = 1;
                            System.out.println("Asiento reservado con exito.");
                        } else {
                            System.out.println("El asiento está ocupado, escoja otro.");
                        }
                        break;
                    case 2:
                        // imprimimos la matriz añadiendo una fila con los índices de las columnas y una columna con los índices de las filas. Si el valor es 1, se imprime una X
                        System.out.println("Los asientos libres se representan con un 0 y los ocupados con una X.");
                        System.out.println();
                        System.out.print("\t");
                        for (int i = 0; i < array[0].length; i++) {
                            System.out.print(i + 1 + "\t"); //ponemos i+1 para que los índices empiecen en 1
                        }
                        System.out.println();
                        for (int i = 0; i < array.length; i++) {
                            System.out.print(i + 1 + "\t"); //ponemos i+1 para que los índices empiecen en 1
                            for (int j = 0; j < array[i].length; j++) {
                                if (array[i][j] == 0) {  //ponemos 0 para los asientos vacíos y X para los ocupados
                                    System.out.print("0\t");
                                } else {
                                    System.out.print("X\t");
                                }
                            }
                            System.out.println();
                        }
                       
                        break;
                    case 3:
                        sc.close(); //cerramos el scanner
                        System.out.println("Hasta pronto.");
                        break;
                    default:
                        System.out.println("Opción incorrecta, intruzca un número del 1 al 3.");
                }
            } while (opcion != 3);


            

            



            
        }  
}
