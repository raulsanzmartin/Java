/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package clases_ej2;
//importar Scanner
import java.util.Scanner;

/**
 *
 * @author alumno
 */
public class Persona {
        //atributos privados nombre y teléfono
    private String nombre;
    private String telefono;
    
    //constructor vacío
    public Persona(){
    }

    //constructor de clase Persona
    private Persona(String nombre, String telefono) {
        this.nombre = nombre;
        this.telefono = telefono;
    }

    //métodos:

    //getter para nombre
    public String getNombre() {
        return nombre;
    }
    //getter para teléfono
    public String getTelefono() {
        return telefono;
    }

    //setter para nombre
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    //setter para teléfono
    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    //método pedirPersona() para introducir por teclado los datos de una persona
    public static Persona pedirPersona(){
        //crear un objeto de la clase Scanner
        var teclado = new Scanner(System.in);
        //pedir los datos de la persona
        System.out.println("Introduce el nombre de la persona: ");
        String nombre = teclado.nextLine();
        System.out.println("Introduce el teléfono de la persona: ");
        String telefono = teclado.nextLine();
        //crear un objeto de la clase Persona
        Persona persona = new Persona();
        //guardar los datos en los atributos del objeto
        persona.setNombre(nombre);
        persona.setTelefono(telefono);
        //devolver el objeto
        return persona;
    }

    //método visualizarPersona() para devolver un string con los datos de la persona
    public String visualizarPersona(){
        //crear un string de ancho de columna fijo con los datos de la persona
        String datos = String.format("%-20s %-20s", this.getNombre(), this.getTelefono());
        //devolver el string
        return datos;
    }

    
}
