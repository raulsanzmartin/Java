/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author alumno
 */
import java.util.Scanner;
import java.util.Random;

public class Alumno {

    // atributos privados
    private String nombre;
    private String apellido1;
    private String apellido2;
    private String grupo;
    private double nota1;
    private double nota2;
    private double nota3;

    // constructor vacío

    public Alumno() {
    }

    // constructor con todos los atributos como parámetros

    public Alumno(String nombre, String apellido1, String apellido2, String grupo, double nota1, double nota2,
            double nota3) {
        this.nombre = nombre;
        this.apellido1 = apellido1;
        this.apellido2 = apellido2;
        this.grupo = grupo;
        this.nota1 = nota1;
        this.nota2 = nota2;
        this.nota3 = nota3;
    }

    // métodos getter

    public String getNombre() {
        return nombre;
    }

    public String getApellido1() {
        return apellido1;
    }

    public String getApellido2() {
        return apellido2;
    }

    public String getGrupo() {
        return grupo;
    }

    public double getNota1() {
        return nota1;
    }

    public double getNota2() {
        return nota2;
    }

    public double getNota3() {
        return nota3;
    }

    // métodos setter

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setApellido1(String apellido1) {
        this.apellido1 = apellido1;
    }

    public void setApellido2(String apellido2) {
        this.apellido2 = apellido2;
    }

    public void setGrupo(String grupo) {
        this.grupo = grupo;
    }

    public void setNota1(double nota1) {
        this.nota1 = nota1;
    }

    public void setNota2(double nota2) {
        this.nota2 = nota2;
    }

    public void setNota3(double nota3) {
        this.nota3 = nota3;
    }

    // // array de 20 elementos con nombres de alumnos, 10 masculinos y 10 femeninos

    // public static String[] arrayNombres = { "Juan", "Pedro", "Luis", "Antonio", "Manuel", "José", "Francisco", "Javier",
    //         "David", "Miguel", "María", "Ana", "Lucía", "Carmen", "Pilar", "Sara", "Laura", "Marta", "Elena", "Rosa" };

    // // array de 20 elementos con apellidos de alumnos

    // public static String[] arrayApellidos = { "García", "González", "Fernández", "López", "Martínez", "Sánchez",
    //         "Pérez", "Gómez", "Ruiz", "Hernández", "Díaz", "Moreno", "Álvarez", "Muñoz", "Romero", "Alonso",
    //         "Gutiérrez", "Navarro", "Torres", "Domínguez" };

    // // array con los elementos DAM1, DAM2,SMR1

    // public static String[] arrayGrupos = { "DAM1", "DAM2", "SMR1" };

    // método generaAlumnoAleatorio() que genera un alumno con nombres, apellidos y
    // grupo aleatorios de los arrays anteriores, y notas aleatorias entre 0 y 10

    public static Alumno generaAlumnoAleatorio() {
        // array de 20 elementos con nombres de alumnos, 10 masculinos y 10 femeninos
        String[] arrayNombres = { "Juan", "Pedro", "Luis", "Antonio", "Manuel", "José", "Francisco", "Javier", "David", "Miguel", "María", "Ana", "Lucía", "Carmen", "Pilar", "Sara", "Laura", "Marta", "Elena", "Rosa" };
        // array de 20 elementos con apellidos de alumnos
        String[] arrayApellidos = { "García", "González", "Fernández", "López", "Martínez", "Sánchez", "Pérez", "Gómez", "Ruiz", "Hernández", "Díaz", "Moreno", "Álvarez", "Muñoz", "Romero", "Alonso", "Gutiérrez", "Navarro", "Torres", "Domínguez" };
        // array con los elementos DAM1, DAM2,SMR1
        String[] arrayGrupos = { "DAM1", "DAM2", "SMR1" };
        // generar números aleatorios
        Random aleatorio = new Random();

        // generar nombre aleatorio
        int numAleatorio = aleatorio.nextInt(20);
        String nombreAleatorio = arrayNombres[numAleatorio];

        // generar apellido1 aleatorio
        numAleatorio = aleatorio.nextInt(20);
        String apellido1Aleatorio = arrayApellidos[numAleatorio];

        // generar apellido2 aleatorio
        numAleatorio = aleatorio.nextInt(20);
        String apellido2Aleatorio = arrayApellidos[numAleatorio];

        // generar grupo aleatorio
        numAleatorio = aleatorio.nextInt(3);
        String grupoAleatorio = arrayGrupos[numAleatorio];

        // generar nota1 aleatoria
        double nota1Aleatoria = aleatorio.nextDouble() * 10;

        // generar nota2 aleatoria
        double nota2Aleatoria = aleatorio.nextDouble() * 10;

        // generar nota3 aleatoria
        double nota3Aleatoria = aleatorio.nextDouble() * 10;

        // crear objeto alumno con los datos aleatorios
        Alumno alumnoAleatorio = new Alumno(nombreAleatorio, apellido1Aleatorio, apellido2Aleatorio, grupoAleatorio,
                nota1Aleatoria, nota2Aleatoria, nota3Aleatoria);

        // devolver el objeto alumno
        return alumnoAleatorio;

    }

    // método alumnoPorTeclado() para crear un alumno con los datos introducidos por
    // teclado

    public static Alumno alumnoPorTeclado() {
                
        //crear objeto scanner
        Scanner teclado = new Scanner(System.in);

        //pedir datos por teclado
        System.out.println("Introduce el nombre del alumno: ");
        String nombre = teclado.nextLine();

        System.out.println("Introduce el primer apellido del alumno: ");
        String apellido1 = teclado.nextLine();

        System.out.println("Introduce el segundo apellido del alumno: ");
        String apellido2 = teclado.nextLine();

        System.out.println("Introduce el grupo del alumno: ");
        String grupo = teclado.nextLine();

        System.out.println("Introduce la nota 1 del alumno: ");
        double nota1 = teclado.nextDouble();

        System.out.println("Introduce la nota 2 del alumno: ");
        double nota2 = teclado.nextDouble();

        System.out.println("Introduce la nota 3 del alumno: ");
        double nota3 = teclado.nextDouble();

        //crear objeto alumno con los datos introducidos por teclado
        Alumno alumnoTeclado = new Alumno(nombre, apellido1, apellido2, grupo, nota1, nota2, nota3);

        //devolver el objeto alumno
        return alumnoTeclado;

    }

    //método mediaAlumno() que calcula la media de las notas de un alumno

    public double mediaAlumno() {

        double media = (nota1 + nota2 + nota3) / 3;

        return media;

    }

    //método visualizarAlumno() para mostrar  por pantalla un alumno en una sola línea, con anchos de columna de 15, para los tres primeros atributos, 10 para el cuatro y 8 para cada nota, y 8 para la nota media.

    public void visualizarAlumno() {

        System.out.printf("%-15s %-15s %-15s %-10s %-8.2f %-8.2f %-8.2f %-8.2f %n", nombre, apellido1, apellido2, grupo, nota1, nota2, nota3, mediaAlumno());

    }

}