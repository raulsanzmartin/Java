/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package clases_ej2;
//importar Scanner
import java.util.Scanner;

/**
 *
 * @author alumno
 */
public class Persona {
        //atributos privados nombre y teléfono
    private String nombre;
    private String telefono;
    private String apellido1;
    private String apellido2;
    
    //constructor vacío
    public Persona(){
    }

    //constructor de clase Persona
    private Persona(String nombre, String telefono, String apellido1, String apellido2) {
        this.nombre = nombre;
        this.telefono = telefono;
        this.apellido1 = apellido1;
        this.apellido2 = apellido2;
    }



    //métodos:

    //getter para nombre
    public String getNombre() {
        return nombre;
    }
    //getter para teléfono
    public String getTelefono() {
        return telefono;
    }

    //getter para apellido1
    public String getApellido1() {
        return apellido1;
    }

    //getter para apellido2
    public String getApellido2() {
        return apellido2;
    }

    //setter para nombre
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    //setter para apellido1

    public void setApellido1(String apellido1) {
        this.apellido1 = apellido1;
    }

    //setter para apellido2
    public void setApellido2(String apellido2) {
        this.apellido2 = apellido2;
    }

    //setter para teléfono
    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    //método pedirPersona() para introducir por teclado los datos de una persona
    public static Persona pedirPersona(){
        //crear un objeto de la clase Scanner
        var teclado = new Scanner(System.in);
        //pedir los datos de la persona
        System.out.println("Introduce el nombre de la persona: ");
        String nombre = teclado.nextLine();
        System.out.println("Introduce el teléfono de la persona: ");
        String telefono = teclado.nextLine();
        //crear un objeto de la clase Persona
        Persona persona = new Persona();
        //guardar los datos en los atributos del objeto
        persona.setNombre(nombre);
        persona.setTelefono(telefono);
        //devolver el objeto
        return persona;
    }

    //método visualizarPersona() para devolver un string con los datos de la persona
    public String visualizarPersona(){
        //crear un string de ancho de columna fijo con los datos de la persona
        String datos = String.format("%-20s %-20s %-20s %-20s", this.getNombre(), this.getApellido1(), this.getApellido2(), this.getTelefono());
        //devolver el string
        return datos;
    }

    //método aleatorioPersona() para llenar un objeto de la clase persona con datos aleatorios de un array de nombres, otro de apellidos y otro de teléfonos
    public static Persona aleatorioPersona(){
        //crear un array de nombres
        String[] nombres = {"Juan", "Pedro", "Luis", "Ana", "María", "Carmen", "Antonio", "José", "Francisco", "Miguel"};
        //crear un array de apellidos
        String[] apellidos = {"García", "González", "López", "Martínez", "Sánchez", "Pérez", "Rodríguez", "Hernández", "Díaz", "Moreno"};
        //crear un array de teléfonos
        String[] telefonos = {"666666666", "777777777", "888888888", "999999999", "555555555", "444444444", "333333333", "222222222", "111111111", "000000000"};
        //crear un objeto de la clase Random
        var aleatorio = new java.util.Random();
        //generar un número aleatorio entre 0 y 9 para cada array
        int nombreAleatorio = aleatorio.nextInt(10);
        int apellidoAleatorio = aleatorio.nextInt(10);
        int apellidoAleatorio2 = aleatorio.nextInt(10);
        int telefonoAleatorio = aleatorio.nextInt(10);
        //crear un objeto de la clase Persona
        Persona personaAleatoria = new Persona();
        //guardar los datos aleatorios en los atributos del objeto
        personaAleatoria.setNombre(nombres[nombreAleatorio]);
        personaAleatoria.setApellido1(apellidos[apellidoAleatorio]);
        personaAleatoria.setApellido2(apellidos[apellidoAleatorio2]);
        personaAleatoria.setTelefono(telefonos[telefonoAleatorio]);
        //devolver el objeto
        return personaAleatoria;
    }
    
}
