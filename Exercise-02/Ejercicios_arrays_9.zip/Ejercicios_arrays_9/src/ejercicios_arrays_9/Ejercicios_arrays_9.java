/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicios_arrays_9;
// import random
import java.util.Random;
// import array
import java.util.Arrays;


/**
 *
 * @author alumno
 */
public class Ejercicios_arrays_9 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // crear una matriz de 10 enteros aleatorios entre 1 y 20 y ordenarlos en orden descendente
        int[] array = new int[10];
        Random random = new Random();
        for (int i = 0; i < array.length; i++) {
            array[i] = random.nextInt(20) + 1;
        }
        // Imprime el array
        System.out.println("Array:" + Arrays.toString(array));
        // Ordena el array en orden ascendente
        for (int i = 0; i < array.length; i++) {
            for (int j = i + 1; j < array.length; j++) {
                if (array[i] < array[j]) {
                    int temp = array[i];
                    array[i] = array[j];
                    array[j] = temp;
                }
            }
        }
        // Imprime el array ordenado
        System.out.println("Array ordenado:" + Arrays.toString(array));
       
    }
    
}
