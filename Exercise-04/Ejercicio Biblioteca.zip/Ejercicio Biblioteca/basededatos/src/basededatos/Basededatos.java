//Haced una aplicación  que utiliza una clase Persona 
//con los atributos nombre y dni. Una clase Alumno que hereda de Persona y tiene como atributo el número de matrícula. 

//En el programa principal un menú con las opciones:

//1. Introducir datos, que pide los datos por teclado y los almacena en una lista.

//2. Almacenar los datos en un fichero.

//3. Almacenar los datos en una base de datos.

//4. Salir.






import java.io.*;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

class Persona {
    String nombre;
    String dni;
}

class Alumno extends Persona {
    String numeroMatricula;
}

public class Basededatos {
    static List<Alumno> alumnos = new ArrayList<>();
    static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        int opcion;
        do {
            System.out.println("Menú:");
            System.out.println("1. Introducir datos");
            System.out.println("2. Almacenar los datos en un fichero");
            System.out.println("3. Almacenar los datos en una base de datos");
            System.out.println("4. Salir");
            opcion = scanner.nextInt();
            scanner.nextLine(); // Consume la nueva línea pendiente

            switch (opcion) {
                case 1:
                    introducirDatos();
                    break;
                case 2:
                    almacenarEnFichero();
                    break;
                case 3:
                    almacenarEnBaseDeDatos();
                    break;
                case 4:
                    System.out.println("Saliendo del programa.");
                    break;
                default:
                    System.out.println("Opción no válida. Introduce un número del 1 al 4.");
            }
        } while (opcion != 4);
    }

    static void introducirDatos() {
        Alumno alumno = new Alumno();
        System.out.print("Introduce el nombre del alumno: ");
        alumno.nombre = scanner.nextLine();
        System.out.print("Introduce el DNI del alumno: ");
        alumno.dni = scanner.nextLine();
        System.out.print("Introduce el número de matrícula del alumno: ");
        alumno.numeroMatricula = scanner.nextLine();
        alumnos.add(alumno);
        System.out.println("Datos del alumno almacenados.");
    }

    static void almacenarEnFichero() {
        try {
            BufferedWriter writer = new BufferedWriter(new FileWriter("alumnos.txt"));
            for (Alumno alumno : alumnos) {
                writer.write("Nombre: " + alumno.nombre + ", DNI: " + alumno.dni + ", Matrícula: " + alumno.numeroMatricula);
                writer.newLine();
            }
            writer.close();
            System.out.println("Datos almacenados en el fichero 'alumnos.txt'.");
        } catch (IOException e) {
            System.out.println("Error al escribir en el fichero.");
        }
    }

    static void almacenarEnBaseDeDatos() {
        String url = "jdbc:mysql://localhost:3306/tu_base_de_datos";
        String usuario = "usuario";
        String contraseña = "contraseña";

        try (Connection conexion = DriverManager.getConnection(url, usuario, contraseña)) {
            for (Alumno alumno : alumnos) {
                String sql = "INSERT INTO alumnos (nombre, dni, matricula) VALUES (?, ?, ?)";
                PreparedStatement statement = conexion.prepareStatement(sql);
                statement.setString(1, alumno.nombre);
                statement.setString(2, alumno.dni);
                statement.setString(3, alumno.numeroMatricula);
                statement.executeUpdate();
            }
            System.out.println("Datos almacenados en la base de datos.");
        } catch (SQLException e) {
            System.out.println("Error al conectar a la base de datos o al ejecutar la consulta.");
            e.printStackTrace();
        }
    }
}


//Este código define tres clases: Persona, Alumno y Main.
//La clase Persona tiene atributos nombre y dni. 
//La clase Alumno hereda de Persona y tiene un atributo adicional numeroMatricula. 
//La clase Main contiene el programa principal con un menú que te permite:

//Introducir datos de un alumno por teclado y almacenarlos en una lista.
//Almacenar los datos en un archivo de texto llamado alumnos.txt.
//Almacenar los datos en una base de datos MySQL. Necesitas configurar la URL, usuario y contraseña para tu base de datos.
//El código está comentado para explicar las diferentes partes y cómo funcionan. Asegúrate de reemplazar "jdbc:mysql://localhost:3306/tu_base_de_datos", "usuario" y "contraseña" con los valores adecuados.

//Ten en cuenta que para ejecutar la parte de almacenamiento en base de datos, necesitas tener un servidor MySQL en funcionamiento y la librería de conexión MySQL en tu proyecto (similar a como lo mencionaste en tu pregunta original).

//Recuerda que este código es una base de partida y puede ser expandido y mejorado según tus necesidades.