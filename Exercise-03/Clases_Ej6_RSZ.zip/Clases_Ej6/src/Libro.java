/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
//importar random
import java.util.Random;
/**
 *
 * @author alumno
 */
public class Libro {
    //Atributos privados título, autores (array de String), editorial, año publicación, páginas, número de ejemplares disponibles, ISBN.
    private String titulo;
    private String[] autores;
    private String editorial;
    private int añoPublicacion;
    private int paginas;
    private int ejemplaresDisponibles;
    private String ISBN;

    //constructor vacío
    public Libro() {
    }

    //constructor con todos los atributos como parámetros
    public Libro(String titulo, String[] autores, String editorial, int añoPublicacion, int paginas, int ejemplaresDisponibles, String ISBN) {
        this.titulo = titulo;
        this.autores = autores;
        this.editorial = editorial;
        this.añoPublicacion = añoPublicacion;
        this.paginas = paginas;
        this.ejemplaresDisponibles = ejemplaresDisponibles;
        this.ISBN = ISBN;
    }

    //métodos getter

    public String getTitulo() {
        return titulo;
    }

    public String[] getAutores() {
        return autores;
    }

    public String getEditorial() {
        return editorial;
    }

    public int getAnioPublicacion() {
        return añoPublicacion;
    }

    public int getPaginas() {
        return paginas;
    }

    public int getEjemplaresDisponibles() {
        return ejemplaresDisponibles;
    }

    public String getISBN() {
        return ISBN;
    }

    //métodos setter

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public void setAutores(String[] autores) {
        this.autores = autores;
    }

    public void setEditorial(String editorial) {
        this.editorial = editorial;
    }

    public void setAñoPublicacion(int añoPublicacion) {
        this.añoPublicacion = añoPublicacion;
    }

    public void setPaginas(int paginas) {
        this.paginas = paginas;
    }

    public void setEjemplaresDisponibles(int ejemplaresDisponibles) {
        this.ejemplaresDisponibles = ejemplaresDisponibles;
    }

    public void setISBN(String ISBN) {
        this.ISBN = ISBN;
    }

    //método para generar un libro aleatorio desde array de autores, editoriales y títulos
    public static Libro generarLibroAleatorio() {
        //array de autores
        String[] auts = {"J. R. R. Tolkien", "J. K. Rowling", "George R. R. Martin", "Stephen King", "J. D. Salinger", "William Shakespeare", "Charles Dickens", "Jane Austen", "Mark Twain", "Ernest Hemingway", "F. Scott Fitzgerald", "Harper Lee", "J. R. R. Tolkien", "J. K. Rowling", "George R. R. Martin", "Stephen King", "J. D. Salinger", "William Shakespeare", "Charles Dickens", "Jane Austen", "Mark Twain", "Ernest Hemingway", "F. Scott Fitzgerald", "Harper Lee", "J. R. R. Tolkien", "J. K. Rowling", "George R. R. Martin", "Stephen King", "J. D. Salinger", "William Shakespeare", "Charles Dickens", "Jane Austen", "Mark Twain", "Ernest Hemingway", "F. Scott Fitzgerald", "Harper Lee", "J. R. R. Tolkien", "J. K. Rowling", "George R. R. Martin", "Stephen King", "J. D. Salinger", "William Shakespeare", "Charles Dickens", "Jane Austen", "Mark Twain", "Ernest Hemingway", "F. Scott Fitzgerald", "Harper Lee", "J. R. R. Tolkien", "J. K. Rowling", "George R. R. Martin", "Stephen King", "J. D. Salinger", "William Shakespeare", "Charles Dickens", "Jane Austen", "Mark Twain", "Ernest Hemingway", "F. Scott Fitzgerald", "Harper Lee", "J. R. R. Tolkien", "J. K. Rowling", "George R. R. Martin", "Stephen King", "J. D. Salinger", "William Shakespeare", "Charles Dickens", "Jane Austen", "Mark Twain", "Ernest Hemingway", "F. Scott Fitzgerald", "Harper Lee", "J. R. R. Tolkien", "J. K. Rowling", "George R. R. Martin", "Stephen King", "J. D. Salinger", "William Shakespeare", "Charles Dickens", "Jane Austen", "Mark Twain", "Ernest Hemingway"};
        //array de títulos
        String[] titulos = {"El Señor de los Anillos", "Harry Potter", "Juego de Tronos", "It", "El Guardián entre el Centeno", "Romeo y Julieta", "Oliver Twist", "Orgullo y Prejuicio", "Las aventuras de Tom Sawyer", "El viejo y el mar", "El gran Gatsby", "Matar un ruiseñor", "El Señor de los Anillos", "Harry Potter", "Juego de Tronos", "It", "El Guardián entre el Centeno", "Romeo y Julieta", "Oliver Twist", "Orgullo y Prejuicio", "Las aventuras de Tom Sawyer", "El viejo y el mar", "El gran Gatsby", "Matar un ruiseñor", "El Señor de los Anillos", "Harry Potter", "Juego de Tronos", "It", "El Guardián entre el Centeno", "Romeo y Julieta", "Oliver Twist", "Orgullo y Prejuicio", "Las aventuras de Tom Sawyer", "El viejo y el mar", "El gran Gatsby", "Matar un ruiseñor", "El Señor de los Anillos", "Harry Potter", "Juego de Tronos", "It", "El Guardián entre el Centeno", "Romeo y Julieta", "Oliver Twist", "Orgullo y Prejuicio", "Las aventuras de Tom Sawyer", "El viejo y el mar", "El gran Gatsby", "Matar un ruiseñor", "El Señor de los Anillos", "Harry Potter", "Juego de Tronos", "It", "El Guardián entre el Centeno", "Romeo y Julieta", "Oliver Twist", "Orgullo y Prejuicio", "Las aventuras de Tom Sawyer", "El viejo y el mar", "El gran Gatsby", "Matar un ruiseñor", "El Señor de los Anillos", "Harry Potter", "Juego de Tronos", "It", "El Guardián entre el Centeno", "Romeo y Julieta", "Oliver Twist", "Orgullo y Prejuicio"};
        //array de editoriales
        String[] editoriales = {"Minotauro", "Planeta", "Salamandra", "Grijalbo", "Minotauro", "Planeta", "Salamandra", "Grijalbo", "Minotauro", "Planeta", "Salamandra", "Grijalbo", "Minotauro", "Planeta", "Salamandra", "Grijalbo", "Minotauro", "Planeta", "Salamandra", "Grijalbo", "Minotauro", "Planeta", "Salamandra", "Grijalbo", "Minotauro", "Planeta", "Salamandra", "Grijalbo", "Minotauro", "Planeta", "Salamandra", "Grijalbo", "Minotauro", "Planeta", "Salamandra", "Grijalbo", "Minotauro", "Planeta", "Salamandra", "Grijalbo", "Minotauro", "Planeta", "Salamandra", "Grijalbo", "Minotauro", "Planeta", "Salamandra", "Grijalbo", "Minotauro", "Planeta", "Salamandra", "Grijalbo", "Minotauro", "Planeta", "Salamandra", "Grijalbo", "Minotauro", "Planeta", "Salamandra", "Grijalbo", "Minotauro", "Planeta", "Salamandra", "Grijalbo", "Minotauro", "Planeta", "Salamandra", "Grijalbo", "Minotauro", "Planeta", "Salamandra", "Grijalbo", "Minotauro", "Planeta", "Salamandra", "Grijalbo", "Minotauro", "Planeta", "Salamandra", "Grijalbo", "Minotauro", "Planeta", "Salamandra", "Grijalbo"};
        //generar aleatoriamente con la funcion Random el número de autores (entre 1 y 3) para determinar el tamaño del array de autores
        Random r = new Random();
        int numAutores = r.nextInt(3) + 1;
        //generar un título aleatorio del array de títulos
        String titulo = titulos[r.nextInt(titulos.length)];
        //array de autores
        String[] autores = new String[numAutores];
        //rellenar el array de autores con nombres aleatorios del array de autores
        for (int i = 0; i < autores.length; i++) {
            autores[i] = auts[r.nextInt(auts.length)];
        }
        //generar editorial aleatoria del array de editoriales
        String editorial = editoriales[r.nextInt(editoriales.length)];
        //generar año aleatorio entre 1900 y 2019
        int anyo = r.nextInt(120) + 1900;
        //generar páginas aleatorias entre 100 y 1000
        int paginas = r.nextInt(901) + 100;
        //generar ejemplares disponibles aleatorios entre 1 y 10
        int ejemplares = r.nextInt(10) + 1;
        //generar isbn aleatorio que será un número de 10 cifras
        String isbn = Integer.toString(r.nextInt(1000000000) + 1000000000);
        //asignar los atributos generados al libro
        return new Libro(titulo, autores, editorial, anyo, paginas, ejemplares, isbn);

    }

    //método para imprimir el título del libro
    public void imprimirLibro() {
        System.out.println(titulo);
    }

    



}

