/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio15;
import java.util.Random;

/**
 *
 * @author alumno
 */
public class Ejercicio15 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Random rd=new Random();
        int[][]alumnos=new int[2][30]; //la primera fila será el número de cada alumno y la segunda, las veces que sale
        int cont,alea,tempalu,tempveces; //cont es el contador para que se eliminen 29 números, temp son las variable temporales en las que almacenamos un valor mientras reordenamos el array
        for (int i = 0; i < 1000; i++) {
            cont=29;
            for (int j = 0; j < alumnos[0].length; j++) {
                alumnos[0][j]=j+1;
            }
            while (cont>0) {
                alea=rd.nextInt(30); //se generarán números del 0 al 29 en lugar de del 1 al 30 para poder utilizarlos como posiciones del array
                if (alumnos[0][alea]!=0) {
                    alumnos[0][alea]=0;
                    cont--;  //metiendo el contador en el if, me aseguro de que si intenta eliminar el mismo número dos veces, el contador no cambie
                }
            }
            for (int j = 0; j < alumnos[0].length; j++) {  //con este for, almacenaremos el alumno seleccionado
                if (alumnos[0][j]!=0) {
                    alumnos[1][j]=alumnos[1][j]+1; //se almacena que ha sido seleccionado una vez más que la última vez que se hizo el proceso
                    j=alumnos[0].length; //con esto salimos del bucle, para no repetirlo innecesariamente una vez se ha localizado el alumno seleccionado
                }
            }
        }
        for (int i = 0; i < alumnos[0].length; i++) {
            alumnos[0][i]=i+1;
        }
        
        
        for (int i = 1; i < alumnos[0].length; i++) {  // con este for se reordena el array
            cont=i;
            while (alumnos[1][cont]>alumnos[1][cont-1]) {
                tempalu=alumnos[0][cont];
                tempveces=alumnos[1][cont];
                alumnos[0][cont]=alumnos[0][cont-1];
                alumnos[0][cont-1]=tempalu;
                alumnos[1][cont]=alumnos[1][cont-1];
                alumnos[1][cont-1]=tempveces;
                if (cont>1) {  // este if se asegura de que nunca se de un número negativo en alumnos[1][cont-1] para que no de error.
                    cont--;                    
                }
            }
        }
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
//        for (int i = 1; i < alumnos[1].length; i++) {
//            tempalu=alumnos[0][i];
//            tempveces=alumnos[1][i];
//            cont=i;
//            pos=cont-1; // pos sirve para ir recorriendo las posiciones anteriores del array y comprobar que están en orden. No puedo usar cont porque me puede dar valores negativos y error
//            while (alumnos[1][i]>alumnos[1][pos] && cont>0) {
//                alumnos[0][cont]=alumnos[0][pos];  // con este bucle iremos moviendo todos los números que son menores hacia la izquierda, duplicándolos, sin peligro de sobreescribir el que estamos queriendo ordenar porque lo hemos almacenado en temp
//                alumnos[1][cont]=alumnos[1][pos];
//                cont=cont-1;
//                if (pos<0) {
//                    pos=cont-1;                    
//                }
//            }
//            alumnos[0][cont]=tempalu;
//            alumnos[1][cont]=tempveces;
//            
//            
//            
//        }
        
        
        System.out.print("Número de alumno:");
        for (int i = 0; i<alumnos[0].length; i++) {
            System.out.printf("%3d |",alumnos[0][i]);
        }
        System.out.printf("%nNúmero de veces: ");
        for (int i = 0; i<alumnos[0].length; i++) {
            System.out.printf("%3d |",alumnos[1][i]);
        }
        System.out.printf("%n%nEl delegado es el alumno %d, seleccionado %d veces.%nEl subdelegado es el alumno %d, seleccionado %d veces.%n%n",alumnos[0][0],alumnos[1][0],alumnos[0][1],alumnos[1][1]);


        
        
        
    }
    
}
