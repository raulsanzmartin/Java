/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package clases_ej4;

/**
 *
 * @author alumno
 */
public class Clases_Ej4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //generar un array de 10 objetos de la clase Alumno rellenados de manera aleatoria con el método generaAlumnoAleatorio()
        Alumno[] arrayAlumnos = new Alumno[10];
        for (int i = 0; i < arrayAlumnos.length; i++) {
            arrayAlumnos[i] = Alumno.generaAlumnoAleatorio();
        }
        

        //imprimir el encabezado con longitud fija
        System.out.printf("%-15s %-15s %-15s %-10s %-8s %-8s %-8s %-8s %n", "Nombre", "Apellido1", "Apellido2", "Grupo", "Nota1", "Nota2", "Nota3", "Media");

        //visualizar cada elemento del array de alumnos utilizando el método visualizarAlumno()
        for (int i = 0; i < arrayAlumnos.length; i++) {
            arrayAlumnos[i].visualizarAlumno();
        }

        //Calculamos la media de las notas de los alumnos del array arrayAlumnos con el método mediaAlumno(), hacemos la media de todas las medias y la mostramos por pantalla
        double media = 0;
        for (int i = 0; i < arrayAlumnos.length; i++) {
            media += arrayAlumnos[i].mediaAlumno();
        }
        media = media / arrayAlumnos.length;
        System.out.println("La nota media de todos alumnos del array es: " + media);


        //generar un array de 3 objetos de la clase Alumno rellenados por teclado con el método alumnoPorTeclado()
        Alumno[] arrayAlumnos2 = new Alumno[3];
        for (int i = 0; i < arrayAlumnos2.length; i++) {
            arrayAlumnos2[i] = Alumno.alumnoPorTeclado();
        }

        //visualizar cada elemento del array de alumnos utilizando el método visualizarAlumno()
        System.out.printf("%-15s %-15s %-15s %-10s %-8s %-8s %-8s %-8s %n", "Nombre", "Apellido1", "Apellido2", "Grupo", "Nota1", "Nota2", "Nota3", "Media");

        for (int i = 0; i < arrayAlumnos2.length; i++) {
            arrayAlumnos2[i].visualizarAlumno();
        }

        









    }
    
}
