/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

/**
 *
 * @author alumno
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // crear un grupo de 25 alumnos de nombre "1º DAM" de forma aleatoria
        GrupoDeClase grupo1 = new GrupoDeClase("1º DAM", 25);
        grupo1.generarGrupo();
        // mostrar los datos de los alumnos del grupo con visualizarGrupo()
        grupo1.visualizarGrupo();
        // calcular la nota media del grupo con mediaGrupo() y mostrarla por pantalla con formato de 2 decimales
        System.out.print("La nota media del grupo "+ grupo1.getNombreGrupo()+" es: ");
        System.out.printf("%.2f%n", grupo1.mediaGrupo());
        // crear un grupo de 5 alumnos de nombre "2º DAM" pidiendo los datos por teclado
        GrupoDeClase grupo2 = new GrupoDeClase("2º DAM", 5);
        grupo2.pedirAlumnosGrupo();
        // mostrar los datos de los alumnos del grupo con visualizarGrupo()
        grupo2.visualizarGrupo();
        System.out.print("La nota media del grupo "+ grupo2.getNombreGrupo()+" es: ");
        System.out.printf("%.2f%n", grupo2.mediaGrupo());
    }
    
}
