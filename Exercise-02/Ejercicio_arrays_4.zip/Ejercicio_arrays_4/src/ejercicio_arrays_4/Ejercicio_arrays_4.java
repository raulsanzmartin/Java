/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio_arrays_4;

import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author alumno
 */
public class Ejercicio_arrays_4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Random rd = new Random();
        Scanner sc = new Scanner(System.in);
        System.out.println("Introduce N");
        int N = sc.nextInt();
        int [] arr = new int[N];
        
        int num;
        boolean existe = false;
        for (int i = 0; i < N; i++) {
            int random = rd.nextInt(20)+1;
            arr[i]=random;           
        }
        
        System.out.println("Introduce un numero: ");
        num = sc.nextInt();
        for (int i = 0; i < N; i++) {
            existe = false;
            if (num == arr[i]) {
                existe = true;
                System.out.print("Existe en las posiciones: ");
                for (int j = 0; j < N; j++) {
                    if (arr[j]==num) {
                        System.out.print(j+1 + ", ");
                    }
                }
            }          
        }
        if (existe==false) {
            System.out.println("El numero no esta en el array");
        }
        System.out.println("");
        System.out.println("El array es: ");
        System.out.print(Arrays.toString(arr));
        
    }
    
    
}
