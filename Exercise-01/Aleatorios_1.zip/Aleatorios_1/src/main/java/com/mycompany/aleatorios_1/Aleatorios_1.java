/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.mycompany.aleatorios_1;

import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author alumno
 */
public class Aleatorios_1 {

    public static void main(String[] args) {
        Random rd=new Random();
        Scanner sc = new Scanner(System.in);//inicializamos el scanner
        int random=rd.nextInt(6); //inicializamos el número aleatorio y le asignamos un integer
        
        //Declaramos variables:
        boolean exit=false; //señal de salida
        String texto;
        
        //Pedimos escribir un número
        System.out.println("Introduzca un número");
        int num = sc.nextInt();
        
        //Bucle principal
        while (random!=num || exit==false){    
            
            System.out.println("¡Fallaste! ¿Desea continuar? (s/n)");
            texto = sc.next();
            
            if (texto.equalsIgnoreCase("n")) {
                exit = true;
                System.out.println("¡Hasta luego!");
                
            }else{
                System.out.println("Introduzca un número");
                num = sc.nextInt();
                if (num == random){
                    System.out.println("¡Correcto!");
                    exit = true;
                }
            }
            
            
        }
    }
}
