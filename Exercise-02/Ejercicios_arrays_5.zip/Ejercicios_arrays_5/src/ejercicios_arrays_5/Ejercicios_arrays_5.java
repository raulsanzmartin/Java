/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicios_arrays_5;

import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author alumno
 */
public class Ejercicios_arrays_5 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Random rd = new Random();
        Scanner sc = new Scanner(System.in);

        //Pedimos el tamaño del array
        System.out.println("Introduce n");
        int n = sc.nextInt();
        int [] arr = new int[n];
        

        int sumapar = 0 , sumaimpar = 0, sumamult = 0, contpar = 0, contimpar = 0;
        float mediapar, mediaimpar;

        // Rellenamos el array con números aleatorios. Si el número es par lo sumamos a la suma de pares y lo contamos. Si es impar lo sumamos a la suma de impares y lo contamos.
        for (int i = 0; i < n; i++) {
            int random = rd.nextInt(20)+1;
            arr[i]=random;            
            if (i%2==0) {
                sumapar = sumapar + arr[i];
                contpar++;
            }else{
                sumaimpar = sumaimpar + arr[i];
                contimpar++;
            }
            if (arr[i]%2==0 && arr[i]%3==0) {
                
                sumamult = sumamult + arr[i];
                System.out.println(arr[i]+": multiplo de 2 y de 3, posicion "+ i);
            }
        }
        // Calculamos las medias
        mediapar = (float)sumapar/contpar;
        mediaimpar = (float)sumaimpar/contimpar;
        
        // Imprimimos
        System.out.println("La suma de los multiplos de 2 y de 3 es: "+sumamult);

        System.out.println("El array es: "+Arrays.toString(arr));
        System.out.println("La suma de las posiciones pares (incluyendo la 0) es: " + sumapar + " y la media: "+ mediapar);
        System.out.println("La suma de las posiciones impares es: " + sumaimpar + " y la media: "+ mediaimpar);
        
        
    }
    
    
}
