/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio16;
import java.util.Random;

/**
 *
 * @author alumno
 */
public class Ejercicio16 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int[][]asig=new int[31][12]; 
        int[]temp=new int[12]; 
        
        Random rd=new Random();
        int suma,cont;
        
        for (int i = 0; i < asig.length; i++) { 
            asig[i][0]=i+1;
        }
        
        for (int i = 0; i < asig.length; i++) { 
            for (int j = 1; j < asig[0].length-1; j++) {
                asig[i][j]=rd.nextInt(20)+1;
            }
        }
        for (int i = 0; i < asig.length; i++) { 
            suma=0;
            for (int j = 1; j < asig[0].length; j++) {
                suma=suma+asig[i][j];
            }
            asig[i][11]=suma;
        }
        

        for (int i = 1; i < asig.length; i++) { 
            cont=i;
            while (asig[cont][11]>asig[cont-1][11]) { 
                for (int j = 0; j < temp.length; j++) {
                    temp[j]=asig[cont][j]; // se almacena la fila que se va a reemplazar en un array de una dimensión temporal, para luego poder copiarla
                    asig[cont][j]=asig[cont-1][j];
                    asig[cont-1][j]=temp[j];
                }
                if (cont>1) { 
                    cont--;
                }
            }
        }

        
        System.out.printf("---------------------------------------------------------------------%n                       LISTADO DE FALTAS%n---------------------------------------------------------------------%nAsignat: ");
        for (int i = 1; i < 11; i++) {
            System.out.printf("%5d",i);
        }
        System.out.printf("  -  Total%n");
        
        for (int i = 0; i < asig.length; i++) {
            System.out.printf("Alumno%3d:",asig[i][0]);
            for (int j = 1; j < asig[0].length-1; j++) {
                System.out.printf("%5d",asig[i][j]);
            }
            System.out.printf("     %d",asig[i][11]);
            System.out.println("");
        }
        
        
            
            
            
            
            
            
            
            
            
            
            
            
            
        }
        
        
        
        
        
        
        
        
    }
    
}
