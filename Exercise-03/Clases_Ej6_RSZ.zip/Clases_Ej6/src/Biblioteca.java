/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
//importar random
import java.util.Random;
/**
 *
 * @author alumno
 */
public class Biblioteca {
    //atributos privados:  un array de libros, un array de lectores y un array de préstamos. 
    private Libro[] libros;
    private Lector[] lectores;
    private Prestamo[] prestamos;

    //constructor vacío
    public Biblioteca() {
    }

    //constructor con todos los atributos como parámetros
    public Biblioteca(Libro[] libros, Lector[] lectores, Prestamo[] prestamos) {
        this.libros = libros;
        this.lectores = lectores;
        this.prestamos = prestamos;
    }
    

    //métodos getter
    public Libro[] getLibros() {
        return libros;
    }

    public Lector[] getLectores() {
        return lectores;
    }

    public Prestamo[] getPrestamos() {
        return prestamos;
    }

    //métodos setter

    public void setLibros(Libro[] libros) {
        this.libros = libros;
    }

    public void setLectores(Lector[] lectores) {
        this.lectores = lectores;
    }

    public void setPrestamos(Prestamo[] prestamos) {
        this.prestamos = prestamos;
    }

    
}
