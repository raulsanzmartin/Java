/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.mycompany.aleatorios_4;

import java.util.Random;

/**
 *
 * @author alumno
 */
public class Aleatorios_4 {

    public static void main(String[] args) {
        Random rd=new Random();
        int random = 1; //
        int cont = 0;
        int suma = 0;
        while (random!=0){
            random = rd.nextInt(11);
            cont ++;
            if (random != 0) {
                suma = suma + random;
                System.out.println(cont+"- Numero generado: "+ random);
            }else{
                System.out.println("Se han generado "+ (cont-1) + " numeros, que en total suman "+suma);
            }
            
        }
        
        
        
    }
}
