
public class Prestamo {
    private Libro libro;
    private Lector lector;
    private int numPrestamo;

    public Prestamo(Libro libro, Lector lector, int numPrestamo) {
        this.libro = libro;
        this.lector = lector;
        this.numPrestamo = numPrestamo;
    }

    // Getters y setters

    // Otros métodos si es necesario
}
