/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author alumno
 */
public class GrupoDeClase {
    //Atributos nombreGrupo, alumnosGrupo
    private String nombreGrupo;
    private Alumno[] alumnosGrupo;

    //Constructor al que se le pasa el nombre del grupo y el número de elementos del array
    public GrupoDeClase(String nombreGrupo, int numAlumnos) {
        this.nombreGrupo = nombreGrupo;
        this.alumnosGrupo = new Alumno[numAlumnos];
    }

    //Métodos getter

    public String getNombreGrupo() {
        return nombreGrupo;
    }

    public Alumno[] getAlumnosGrupo() {
        return alumnosGrupo;
    }

    //Métodos setter

    public void setNombreGrupo(String nombreGrupo) {
        this.nombreGrupo = nombreGrupo;
    }

    public void setAlumnosGrupo(Alumno[] alumnosGrupo) {
        this.alumnosGrupo = alumnosGrupo;
    }

    //método generarGrupo() para generar un grupo de alumnos aleatorios con el método generaAlumnoAleatorio() de la clase Alumno
    
    public void generarGrupo() {
        for (int i = 0; i < alumnosGrupo.length; i++) {
            alumnosGrupo[i] = Alumno.generaAlumnoAleatorio();
        }
        //cambiar el nombre del grupo de todos los alumnos por el grupo del que forman parte
        for (int i = 0; i < alumnosGrupo.length; i++) {
            alumnosGrupo[i].setGrupo(nombreGrupo);
        }
    }

    //método pedirAlumnosGrupo() para pedir los datos de los alumnos del grupo por teclado con el método alumnoPorTeclado() de la clase Alumno
    
    public void pedirAlumnosGrupo() {
        for (int i = 0; i < alumnosGrupo.length; i++) {
            alumnosGrupo[i] = Alumno.alumnoPorTeclado();
        }
        //cambiar el nombre del grupo de todos los alumnos por el grupo del que forman parte
        for (int i = 0; i < alumnosGrupo.length; i++) {
            alumnosGrupo[i].setGrupo(nombreGrupo);
        }
    }

    //método mediaGrupo() para calcular la media de las notas de todos los alumnos del grupo

    public double mediaGrupo() {
        double media = 0;
        for (int i = 0; i < alumnosGrupo.length; i++) {
            media += alumnosGrupo[i].mediaAlumno();
        }
        return media / alumnosGrupo.length;
    }

    //método visualizarGrupo() para visualizar los datos de todos los alumnos del grupo, utilizando el método visualizarAlumno() de la clase Alumno
    
    public void visualizarGrupo() {
        System.out.printf("%-15s %-15s %-15s %-10s %-8s %-8s %-8s %-8s %n", "Nombre", "Apellido1", "Apellido2", "Grupo", "Nota1", "Nota2", "Nota3", "Media");
        for (int i = 0; i < alumnosGrupo.length; i++) {
            alumnosGrupo[i].visualizarAlumno();
        }
    }




}
