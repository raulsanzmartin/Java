/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio_arrays_1;

import java.util.Scanner;
import java.util.Arrays;

/**
 *
 * @author alumno
 */
public class Ejercicio_Arrays_1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);//inicializamos el scanner
        int i = 0;
        int num;
        boolean rep;
        int [] arr = new int[10];
        
        
        while(i<10){
            rep = false;
            System.out.println("introducir numero");
            num = sc.nextInt();
            for (int n:arr){               
                if (n == num){
                    rep = true;                                 
                }  
            }
            
            if (rep==false) {
                arr[i] = num;
                i++;
                System.out.println(Arrays.toString(arr));
            }else{
                System.out.println("Numero repetido");
            }
            
            
          
        }
 
        
    }
    
}
