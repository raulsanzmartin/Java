/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package clases_ej1;

/**
 *
 * @author alumno
 */
public class Persona {
    //atributos privados nombre y teléfono
    private String nombre;
    private String telefono;
    
    //constructor vacío
    public Persona(){
    }

    //constructor de clase Persona
    private Persona(String nombre, String telefono) {
        this.nombre = nombre;
        this.telefono = telefono;
    }

    //métodos:

    //getter para nombre
    public String getNombre() {
        return nombre;
    }
    //getter para teléfono
    public String getTelefono() {
        return telefono;
    }

    //setter para nombre
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    //setter para teléfono
    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    
}
