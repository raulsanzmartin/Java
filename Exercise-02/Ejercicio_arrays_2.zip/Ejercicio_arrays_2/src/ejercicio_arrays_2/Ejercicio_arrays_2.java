/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio_arrays_2;

import java.util.Arrays;
import java.util.Collections;
import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author alumno
 */
public class Ejercicio_arrays_2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Random rd = new Random();
        Scanner sc = new Scanner(System.in);
        System.out.println("Introduce N");
        int n = sc.nextInt();
        int [] arr = new int[n];
        int [] revarr = new int[n];
        for (int i = 0; i < n; i++) {
            int random = rd.nextInt(50)+1;
            arr[i]=random;
        }
        int j = n-1;
        for (int i = 0; i < n; i++) {
            revarr[i] = arr[j];
            j--;
        }

        System.out.println("Array normal: " + Arrays.toString(arr));
        System.out.println("Array invertido: " + Arrays.toString(revarr));
      
    }
    
}
