import java.util.*;

public class Biblioteca {
    private List<Libro> listaLibros;
    private List<Lector> listaLectores;
    private List<Prestamo> listaPrestamos;
    private int proximoNumeroPrestamo;

    public Biblioteca() {
        listaLibros = new ArrayList<>();
        listaLectores = new ArrayList<>();
        listaPrestamos = new ArrayList<>();
        proximoNumeroPrestamo = 1;
    }

    public boolean validarPrestamo(String isbn, String dni) {
        // Implementación para validar si es posible realizar un préstamo
        // Verifica disponibilidad de libro y límite de préstamos por lector
        // Devuelve true si es posible, false si no
        return false;
        // Implementación para validar si es posible realizar un préstamo
        // Verifica disponibilidad de libro y límite de préstamos por lector
        // Devuelve true si es posible, false si no
    }

    public void realizarPrestamo(String isbn, String dni) {
        // Implementación para realizar el préstamo
        // Actualiza las listas de libros, lectores y préstamos
    }

    public void mostrarRelacionPrestamos() {
        // Implementación para mostrar la relación de préstamos
        // Imprime el número de préstamo, título del libro y nombre del lector
    }

    public void cargarLectoresDesdeArchivo(String nombreArchivo, boolean eliminarDatosActuales) {
        // Implementación para cargar lectores desde un archivo de texto
        // Si eliminarDatosActuales es true, se eliminan los datos actuales antes de cargar
    }

    public void cargarLibrosDesdeArchivo(String nombreArchivo, boolean eliminarDatosActuales) {
        // Implementación para cargar libros desde un archivo binario
        // Si eliminarDatosActuales es true, se eliminan los datos actuales antes de cargar
    }

    public void guardarPrestamosEnArchivo() {
        // Implementación para guardar préstamos en un archivo binario
    }

    // Otros métodos si es necesario
}
