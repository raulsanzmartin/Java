/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicios_arrays_6;

import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author alumno
 */
public class Ejercicios_arrays_6 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Random rd = new Random();
        Scanner sc = new Scanner(System.in);
        
        //Pedimos N por teclado
        System.out.println("Introduzca N:");
        int n = sc.nextInt();
        int [] arr = new int[n];
        
        int npar = 0, nimpar = 0; // Contadores de pares e impares
        
        System.out.println("¿Quiere generar los numeros al azar?(s/n)");
        String resp = sc.next();
        
        // Rellenamos el array, o con números aleatorios o con los introducidos por teclado
        if (resp.equalsIgnoreCase("s") ) {
            for (int i = 0; i < n; i++) {
                int random = rd.nextInt(20)+1;
                arr[i]=random;
            }
        
        }else{
            for (int i = 0; i < n; i++) {
                System.out.println("Introduzca un numero en la posicion "+i+":");
                arr[i] = sc.nextInt();
            }        
        }
        // Miramos si el número es par o impar y lo sumamos al contador correspondiente
        for (int i = 0; i < n; i++) {
            if (arr[i]%2==0) {
                npar++;
            }else{
                nimpar++;
            }
        }

        // Inicializamos los arrays de pares e impares con los tamaños de los contadores
        int [] arrpar = new int[npar];
        int [] arrimpar = new int[nimpar];

        // Ponemos los contadores a 0 para volver a usarlos
        npar = 0;
        nimpar = 0;

        // Recorremos el array principal. Si el número es par lo metemos en el array de pares y si es impar en el de impares
        for (int i = 0; i < n; i++) {
            if (arr[i]%2==0) {
                
                arrpar[npar]=arr[i];
                npar++;
            }else{
                
                arrimpar[nimpar]=arr[i];
                nimpar++;
            }
        }
        // Imprimimos
        System.out.println("Matriz: " + Arrays.toString(arr));
        System.out.println("Matriz par: " + Arrays.toString(arrpar));
        System.out.println("Matriz impar: " + Arrays.toString(arrimpar));
        
        
       
        
        
        
    }
    
}
