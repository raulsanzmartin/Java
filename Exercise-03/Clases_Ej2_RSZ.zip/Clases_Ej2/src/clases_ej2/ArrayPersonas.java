/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package clases_ej2;

/**
 *
 * @author alumno
 */
public class ArrayPersonas {
    //variable privada de array de objetos de la clase Persona
    private Persona[] arrayPersonas;


    //constructor vacío
    public ArrayPersonas(){
    }

    //constructor de clase ArrayPersonas. Recibe como parámetro un array de objetos de la clase Persona
    public ArrayPersonas(Persona[] arrayPersonas) {
        this.arrayPersonas = arrayPersonas;
    }
    //método llenarArrayPersonas() para introducir por teclado los datos de un array de personas
    public static void llenarArrayPersonas(Persona[] arrayPersonas){
        //recorrer el array y pedir los datos de cada persona
        for (int i = 0; i < arrayPersonas.length; i++) {
            arrayPersonas[i] = Persona.pedirPersona();
        }
    }

    //método visualizarArrayPersonas() para mostrar por pantalla los datos de un array de personas utilizando el método visualizarPersona() de la clase Persona
    public static void visualizarArrayPersonas(Persona[] arrayPersonas){
        //imprimir el encabezado con longitud fija
        System.out.printf("%-20s %-20s %n", "Nombre", "Teléfono");
        //imprimir los datos obtenidos del método visualizarPersona() de la clase Persona
        for (int i = 0; i < arrayPersonas.length; i++) {
            System.out.println(arrayPersonas[i].visualizarPersona());
        }


    }

}
