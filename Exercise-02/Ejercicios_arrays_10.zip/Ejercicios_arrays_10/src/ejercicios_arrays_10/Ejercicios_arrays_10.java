/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicios_arrays_10;
// importa random
import java.util.Random;
// importa array
import java.util.Arrays;
// importa scanner
import java.util.Scanner;


/**
 *
 * @author alumno
 */
public class Ejercicios_arrays_10 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // introducir por teclado un número inferior a 50. Si el número es superior a 50, introdúzcalo de nuevo hasta que sea correcto.
        
        Scanner keyboard = new Scanner(System.in);
        int n;
        do {
            System.out.println("Introduce un numero menor que 50:");
            n = keyboard.nextInt();
        } while (n >= 50);
        System.out.println("N = " + n);

        // crear un array de n elementos y llenarlo con números aleatorios entre 1 y 100 y mostrar el mayor y su posición
        int[] array = new int[n];
        Random random = new Random();
        for (int i = 0; i < array.length; i++) {
            array[i] = random.nextInt(100) + 1;
        }

        // Imprimir la matriz
        System.out.println("Array:" + Arrays.toString(array));

        // busca el número mayor y su posición
        int mayor = 0;
        int posicion = 0;
        for (int i = 0; i < array.length; i++) {
            if (array[i] > mayor) {
                mayor = array[i];
                posicion = i + 1;
            }
        }

        // Imprime el número mayor y su posición
        System.out.println("El numero mas alto es: " + mayor + " en la posicion " + posicion + "(empezando desde 1 hasta " + array.length + ")");
    }
    
}
