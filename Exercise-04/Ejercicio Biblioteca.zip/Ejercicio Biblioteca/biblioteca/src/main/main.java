import java.util.Scanner;

public class Examen3ev {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Biblioteca biblioteca = new Biblioteca();

        int opcion;
        do {
            System.out.println("Menú:");
            System.out.println("1. Realizar préstamo");
            System.out.println("2. Relación de préstamos");
            System.out.println("3. Cargar lectores desde fichero");
            System.out.println("4. Cargar libros desde fichero");
            System.out.println("5. Guardar préstamos en fichero");
            System.out.println("6. Salir");
            System.out.print("Selecciona una opción: ");
            opcion = scanner.nextInt();
            scanner.nextLine();  // Consume la nueva línea después del número

            switch (opcion) {
                case 1:
                    realizarPrestamo(biblioteca, scanner);
                    break;
                case 2:
                    mostrarRelacionPrestamos(biblioteca);
                    break;
                case 3:
                    cargarLectoresDesdeArchivo(biblioteca, scanner);
                    break;
                case 4:
                    cargarLibrosDesdeArchivo(biblioteca);
                    break;
                case 5:
                    guardarPrestamosEnArchivo(biblioteca);
                    break;
                case 6:
                    System.out.println("Saliendo del programa...");
                    break;
                default:
                    System.out.println("Opción inválida. Introduce un número del 1 al 6.");
                    break;
            }
        } while (opcion != 6);
    }

    public static void realizarPrestamo(Biblioteca biblioteca, Scanner scanner) {
        // Implementación para realizar préstamo
    }

    public static void mostrarRelacionPrestamos(Biblioteca biblioteca) {
        // Implementación para mostrar relación de préstamos
    }

    public static void cargarLectoresDesdeArchivo(Biblioteca biblioteca, Scanner scanner) {
        // Implementación para cargar lectores desde archivo
    }

    public static void cargarLibrosDesdeArchivo(Biblioteca biblioteca) {
        // Implementación para cargar libros desde archivo
    }

    public static void guardarPrestamosEnArchivo(Biblioteca biblioteca) {
        // Implementación para guardar préstamos en archivo
    }
}
