/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.mycompany.ejercicioarray12;

/**
 *
 * @author alumno
 */
public class Ejercicioarray12 {

    public static void main(String[] args) {
        int n=0,m=0;
        int matriz [][]={{1,2,3},{4,5,6},{7,8,9},{10,11,12}};
        for (int i=0;i<matriz.length;i++){
            for (int j=0;j<matriz[i].length;j++){
                System.out.print(matriz[i][j]);
                m=m+matriz[i][j];
            }
            System.out.print ("="+m);
            m=0;
            System.out.println("");
        }
        System.out.print ("= = =");
        System.out.println("");
        for (int i=0;i<3;i++){
            n=0;
            for (int j=0;j<4;j++){
                n=n+matriz[j][i];
            }
            System.out.print (n+" ");
        }

    }
}
