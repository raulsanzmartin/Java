/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.mycompany.ejercicioarray11;

/**
 *
 * @author alumno
 */
public class Ejercicioarray11 {

    public static void main(String[] args) {
        int matriz [][]={{ 1, 2, 3},{ 4, 5, 6},{ 7, 8, 9},{ 10, 11, 12}};
        for (int i=0;i<matriz.length;i++){
            System.out.println("");
            for (int j=0;j<matriz[i].length;j++){
                System.out.print(matriz[i][j]);
            }
        }
    }
}
