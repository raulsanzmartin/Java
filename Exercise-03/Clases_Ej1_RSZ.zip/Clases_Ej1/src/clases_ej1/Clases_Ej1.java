/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package clases_ej1;
//importar Scanner
import java.util.Scanner;
//importar clase Persona


/**
 *
 * @author alumno
 */


public class Clases_Ej1 {
    
    
    //método para rellenar un vector de objetos de la clase Persona llenarTeclado()
    public static void llenarTeclado(Persona[] vector){
        //crear un objeto de la clase Scanner
        Scanner teclado = new Scanner(System.in);
        //recorrer el vector de objetos de la clase Persona y pedir los datos de los atributos
        for (int i = 0; i < vector.length; i++) {
            System.out.println("Introduce el nombre de la persona " + (i+1) + ": ");
            String nombre = teclado.nextLine();
            System.out.println("Introduce el teléfono de la persona " + (i+1) + ": ");
            String telefono = teclado.nextLine();
            //crear un objeto de la clase Persona
            Persona persona = new Persona();
            //guardar los datos en los atributos del objeto
            persona.setNombre(nombre);
            persona.setTelefono(telefono);
            
            //guardar el objeto en el vector
            vector[i] = persona;
        }
    }

    //método para imprimir el vector de objetos de la clase Persona visualizarArray().
    public static void visualizarArray(Persona[] vector){
        //imprimir encabezados
        System.out.printf("%-10s %-10s %n", "Nombre", "Teléfono");
        //recorrer el vector y imprimir los datos de cada objeto
        for (int i = 0; i < vector.length; i++) {
            System.out.printf("%-10s %-10s %n", vector[i].getNombre(), vector[i].getTelefono());
        }
    }    
    
    
    
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // crear un array con 3 objetos de la clase Persona
        Persona[] vector = new Persona[3];
        //rellenar el array con los datos de las personas
        llenarTeclado(vector);
        //visualizar el array
        visualizarArray(vector);

    }
    
}
