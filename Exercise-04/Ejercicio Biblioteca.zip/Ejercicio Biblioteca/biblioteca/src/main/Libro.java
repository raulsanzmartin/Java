public class Libro {
    private String titulo;
    private String autor;
    private String editorial;
    private int anioPublicacion;
    private int paginas;
    private int numEjemplaresDisponibles;
    private String isbn;
    private float precio;

    public Libro(String titulo, String autor, String editorial, int anioPublicacion, int paginas,
                 int numEjemplaresDisponibles, String isbn, float precio) {
        this.titulo = titulo;
        this.autor = autor;
        this.editorial = editorial;
        this.anioPublicacion = anioPublicacion;
        this.paginas = paginas;
        this.numEjemplaresDisponibles = numEjemplaresDisponibles;
        this.isbn = isbn;
        this.precio = precio;
    }

    // Getters y setters

    // Otros métodos si es necesario
}
