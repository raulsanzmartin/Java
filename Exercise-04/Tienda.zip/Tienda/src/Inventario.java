
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author manana
 */
public class Inventario {
    // atributos
    private List<Producto> productos;

    // constructor
    public Inventario(List<Producto> productos) {
        this.productos = productos;
    }

    // constructor vacío
    public Inventario() {
        productos = new ArrayList<>();
    }

    // getters y setters
    public List<Producto> getProductos() {
        return productos;
    }

    public void setProductos(List<Producto> productos) {
        this.productos = productos;
    }

    // métodos
    // generar un inventario de 20 productos con nombre, precio y cantidad
    // aleatorios
    public void generarInventario() {
        for (int i = 1; i <= 20; i++) {
            Producto p = new Producto();
            p.setNombre("Producto " + i);
            p.setPrecio(Math.random() * 100);
            p.setCantidad((int) (Math.random() * 100));
            productos.add(p);
        }
    }

    // mostrar el inventario en columnas de ancho fijo
    public void mostrarInventario() {
        System.out.printf("%-20s %-10s %-10s %n", "Nombre", "Precio", "Cantidad");
        for (Producto p : productos) {
            System.out.printf("%-20s %-10.2f %-10d %n", p.getNombre(), p.getPrecio(), p.getCantidad());
        }
    }

    // vender producto
    public void venderProducto() {
        // introducir nombre del producto por teclado
        Scanner sc = new Scanner(System.in);
        System.out.println("Introduce el nombre del producto");
        String nombre = sc.nextLine();
        // comprobar si el producto existe
        boolean existe = false;
        for (Producto p : productos) {
            if (p.getNombre().equals(nombre)) {
                // introducir la cantidad a vender por teclado
                System.out.println("Introduce la cantidad a vender");
                int cantidad = sc.nextInt();
                p.setCantidad(p.getCantidad() - cantidad);
                existe = true;
                System.out.println("-----------------------");
                System.out.println("¡Producto vendido!");
                System.out.println("-----------------------");
            }
            if (!existe) {
                System.out.println("El producto no existe");
            }
        }
    }

    // añadir producto
    public void añadirProducto() {
        Scanner sc = new Scanner(System.in);
        System.out.println("Introduce el nombre del producto");
        String nombre = sc.nextLine();
        // comprobamos si existe un producto con ese nombre. Si existe, añadimos la
        // cantidad. Si no existe, creamos un nuevo producto
        boolean existe = false;
        for (Producto p : productos) {
            if (p.getNombre().equals(nombre)) {
                System.out.println("Introduce la cantidad a añadir");
                int cantidad = sc.nextInt();
                p.setCantidad(p.getCantidad() + cantidad);
                existe = true;
                System.out.println("-----------------------");
                System.out.println("¡Producto añadido!");
                System.out.println("-----------------------");
            }

        }
        if (!existe) {
            Producto p = new Producto();
            p.setNombre(nombre);
            System.out.println("Introduce la cantidad a añadir");
            int cantidad = sc.nextInt();
            p.setCantidad(cantidad);
            // introducir precio por teclado
            System.out.println("Introduce el precio del producto");
            p.setPrecio(sc.nextDouble());
            productos.add(p);
            System.out.println("-----------------------");
            System.out.println("¡Producto añadido!");
            System.out.println("-----------------------");
        }

    }
}
