/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.mycompany.aleatorios_2;

import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author alumno
 */
public class Aleatorios_2 {

    public static void main(String[] args) {
        Random rd=new Random();
        Scanner sc = new Scanner(System.in);//inicializamos el scanner
        int random=rd.nextInt(100)+1; //inicializamos el número aleatorio y le asignamos un integer
        System.out.println("Introduzca un número");
        int num = sc.nextInt();
        int cont = 0;
        while (num!=random){
            cont ++;
            if (num<random) {
                System.out.println("¡Fallaste! El número que buscas es mas alto");
            }else{
                System.out.println("¡Fallaste! El número que buscas es mas bajo");
            }
            System.out.println("Llevas " + cont + " intentos, introduzca un nuevo número");
            num = sc.nextInt();
           
        }
        System.out.println("¡Correcto!");
        
    }
}
