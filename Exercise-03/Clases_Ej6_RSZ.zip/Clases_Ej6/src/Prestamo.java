/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author alumno
 */
public class Prestamo {

    //atributos privados: libro, lector y número de préstamo
    private Libro libro;
    private Lector lector;
    private int numeroPrestamo;

    //constructor vacío
    public Prestamo() {
    }

    //constructor con todos los atributos como parámetros
    public Prestamo(Libro libro, Lector lector, int numeroPrestamo) {
        this.libro = libro;
        this.lector = lector;
        this.numeroPrestamo = numeroPrestamo;
    }

    //métodos getter
    public Libro getLibro() {
        return libro;
    }

    public Lector getLector() {
        return lector;
    }

    public int getNumeroPrestamo() {
        return numeroPrestamo;
    }

    //métodos setter
    public void setLibro(Libro libro) {
        this.libro = libro;
    }

    public void setLector(Lector lector) {
        this.lector = lector;
    }

    public void setNumeroPrestamo(int numeroPrestamo) {
        this.numeroPrestamo = numeroPrestamo;
    }

    //método para imprimir los datos del préstamo
    public void imprimirPrestamo() {
        System.out.println("Número de préstamo: " + numeroPrestamo);
        System.out.println("Datos del libro:");
        libro.imprimirLibro();
        System.out.println("Datos del lector:");
        lector.imprimirLector();
    }

    

  
}
