/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicios_arrays_8;
import java.util.Arrays;
//import random
import java.util.Random;

/**
 *
 * @author alumno
 */
public class Ejercicios_arrays_8 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // Crear una matriz de 10 enteros aleatorios entre 1 y 100
        int[] array = new int[10];
        Random random = new Random();
        for (int i = 0; i < array.length; i++) {
            array[i] = random.nextInt(100) + 1;
        }
        
        

        // Imprime el array
        System.out.println("Array:" + Arrays.toString(array));
        // Crear una nueva matriz con la misma longitud que la primera matriz
        int[] array2 = new int[array.length];
        // Copiar los elementos del primer array al segundo array de forma que si el elemento es par, se añade al principio del segundo array, y si es impar, se añade al final del segundo array
        int even = 0;
        int odd = array2.length - 1;
        for (int i = 0; i < array.length; i++) {
            if (array[i] % 2 == 0) {// si es par
                array2[even] = array[i];// añade al principio
                even++;
            } else {// si es impar
                array2[odd] = array[i];// añade al final
                odd--;
            }
        } // Imprime el segundo array
        System.out.println("Array2:" + Arrays.toString(array2));
       




    }
    
}
