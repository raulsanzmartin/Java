/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicios_arrays_7;

import java.util.Arrays;
import java.util.Random;

/**
 *
 * @author alumno
 */
public class Ejercicios_arrays_7 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Random rd = new Random();      
        int n = 2, random, sumapares = 0, sumaimpares = 0;
        
        // Inicializamos el array
        int[] arr1 = new int[n];
        int[] arr2 = new int[n];
        
        // Rellenamos los arrays con números aleatorios
        for (int i = 0; i < n; i++) {
            random = rd.nextInt(100)+1;
            arr1[i]=random;
            random = rd.nextInt(100)+1;
            arr2[i]=random;
            // Enviamos los números en posicion par a la suma de pares y los de posicion impar a la suma de impares
            if (i%2==0) {
                sumapares = sumapares + arr1[i];
                
            }else{
                sumaimpares = sumaimpares + arr2[i];
                
            
            }
        }
        //Imprimimos
        System.out.println("Matriz 1: " + Arrays.toString(arr1));
        System.out.println("Matriz 2: " +Arrays.toString(arr2));
        System.out.println("suma pares e impares: " + (sumapares+sumaimpares));
    }
    
}
