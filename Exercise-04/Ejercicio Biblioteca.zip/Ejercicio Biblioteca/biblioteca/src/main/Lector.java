/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
public class Lector {
    private String nombre;
    private String dni;
    private int numLibrosPrestados;

    public Lector(String nombre, String dni) {
        this.nombre = nombre;
        this.dni = dni;
        this.numLibrosPrestados = 0;
    }

    // Getters y setters

    // Otros métodos si es necesario
}
