/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio_arrays_3;

import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author alumno
 */
public class Ejercicio_arrays_3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Random rd = new Random();
        Scanner sc = new Scanner(System.in);
        System.out.println("Introduce N");
        int N = sc.nextInt();
        int [] arr = new int[N];
        int max = arr[1];
        for (int i = 0; i < N; i++) {
            int random = rd.nextInt(20)+1;
            arr[i]=random;
            for (int j = 0; j < N; j++) {                       
                if (max < arr[j] ){
                    max = arr[j];
                    
                }
            }
        }        
        System.out.println(Arrays.toString(arr));
        System.out.println("Maximo: "+ max);
        System.out.print("Posiciones del maximo: ");
        for (int i = 0; i < N; i++) {
            if (arr[i]==max) {
                System.out.print(i+1 + ", ");
            }
        }
    }
    
}
