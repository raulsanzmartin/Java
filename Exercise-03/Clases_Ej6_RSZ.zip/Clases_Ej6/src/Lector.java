/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
//importar random
import java.util.Random;
/**
 *
 * @author alumno
 */
public class Lector {
    //atributos privados : nombre, dni, número de libros prestados.
    private String nombre;
    private String dni;
    private int librosPrestados;

    //constructor vacío
    public Lector() {
    }

    //constructor con todos los atributos como parámetros
    public Lector(String nombre, String dni, int librosPrestados) {
        this.nombre = nombre;
        this.dni = dni;
        this.librosPrestados = librosPrestados;
    }

    //métodos getter
    public String getNombre() {
        return nombre;
    }

    public String getDNI() {
        return dni;
    }

    public int getLibrosPrestados() {
        return librosPrestados;
    }

    //métodos setter

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setDNI(String dni) {
        this.dni = dni;
    }

    public void setLibrosPrestados(int librosPrestados) {
        this.librosPrestados = librosPrestados;
    }

    //método para generar lector aleatorio
    public static Lector generarLectorAleatorio(){

        //array con 30 nombres y apellidos
        String[] nombres = {"Juan Pérez", "Ana López", "María García", "Luis Martínez", "Antonio Sánchez", "Francisco Jiménez", "Josefa Fernández", "Dolores Rodríguez", "Marta Martín", "Carmen González", "Manuel Gómez", "María Ruiz", "Jesús Hernández", "Dolores Moreno", "Miguel Domínguez", "Francisco Muñoz", "María Sánchez", "Josefa García", "Antonio López", "Luis Martínez", "Ana Martín", "Miguel García", "Francisco Martín", "Miguel Martín", "Francisco Martínez", "Miguel Martínez", "Francisco Martín", "Miguel Martín", "Francisco Martínez", "Miguel Martínez"};
        //generar nombre aleatorio con random del array nombres
        Random random = new Random();
        int nombreAleatorio = random.nextInt(nombres.length);
        String nomb = nombres[nombreAleatorio];

        //generar dni aleatorio con random y letra aleatoria al final. 8 números y 1 letra
        String DNI = "";
        for (int i = 0; i < 8; i++) {
            DNI += random.nextInt(10);
        }
        String[] letras = {"A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z"};
        int letraAleatoria = random.nextInt(letras.length);
        DNI += letras[letraAleatoria];

        //crear objeto lector con los datos aleatorios
        return new Lector(nomb, DNI, 0);

    }

    //método para imprimir el dni del lector
    public void imprimirLector(){
        System.out.println(dni);
    }
}
