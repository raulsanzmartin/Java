/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
//importar scanner
import java.util.Scanner;
//importar Arrays
import java.util.Arrays;
/**
 *
 * @author alumno
 */
public class Main {

    /**
     * @param args the command line arguments
     * 
     * 
     */


    public static void main(String[] args) {       
        //crear un objeto de la clase Scanner
        Scanner sc = new Scanner(System.in);
        
        //crear un array de objetos de la clase Libro con 300 libros usando el método generarLibroAleatorio() de la clase Libro sin repetir ningún ISBN. utilizar un bucle for y un while
        Libro[] libros = new Libro[300];
        for (int i = 0; i < libros.length; i++) {
            libros[i] = Libro.generarLibroAleatorio();
            for (int j = 0; j < i; j++) {
                if (libros[i].getISBN().equals(libros[j].getISBN())) {
                    i--;
                }
            }
        }

        //crear un array de objetos de la clase Lector con 50 lectores usando el método generarLectorAleatorio() de la clase Lector sin repetir DNI más de 3 veces. utilizar un bucle for y un while
        Lector[] lectores = new Lector[50];
        for (int i = 0; i < lectores.length; i++) {
            lectores[i] = Lector.generarLectorAleatorio();
            int contador = 0;
            for (int j = 0; j < i; j++) {
                if (lectores[i].getDNI().equals(lectores[j].getDNI())) {
                    contador++;
                }
            }
            if (contador > 2) {
                i--;
            }
        }


        //crear un array de 150 objetos de la clase Prestamos
        Prestamo[] prestamos = new Prestamo[150];




        //crear un objeto de la clase Biblioteca con los arrays de libros, lectores y prestamos
        Biblioteca biblioteca = new Biblioteca(libros, lectores, prestamos);

        //menu con  realizar préstamo, devolver libro, relación de préstamos (número de préstamo, título del libro y nombre del lector) y salir
        int opcion = 0;
        do {
            System.out.println("--------------------------------------------------------------------------------");
            System.out.println("1. Realizar préstamo");
            System.out.println("2. Devolver libro");
            System.out.println("3. Relación de préstamos");
            System.out.println("4. Salir");
            System.out.println("--------------------------------------------------------------------------------");
            opcion = sc.nextInt();
            switch (opcion) {
                case 1 -> {
                    //imprimir título, autores, ISBN y ejemplares disponibles del array de libros en columnas de ancho fijo con encabezados (con printf). Los autores se mostraran con Arrays.toString(). Añadir un indice a cada libro para que el usuario pueda seleccionar el libro que quiere prestar.
                    System.out.printf("%-10s %-30s %-15s %-65s %-15s %n", "Índice", "Título", "Ejemplares", "Autores", "ISBN");
                    for (int i = 0; i < libros.length; i++) {
                        System.out.printf("%-10s %-30s %-15s %-65s %-15s %n", i, libros[i].getTitulo(), libros[i].getEjemplaresDisponibles(), Arrays.toString(libros[i].getAutores()), libros[i].getISBN());
                    }
                    System.out.println("--------------------------------------------------------------------------------");

                    //pedir al usuario que introduzca el índice del libro que quiere prestar
                    System.out.println("Introduzca el índice del libro a prestar");
                    int indiceLibro = sc.nextInt();
                    System.out.println("--------------------------------------------------------------------------------");
                    
                    //utilizar el método comprobarLibro() para comprobar que el libro no ha sido prestado más veces que el número de ejemplares. 
                    if (libros[indiceLibro].getEjemplaresDisponibles() > 0) {
                        //imprimir nombre, apellidos y DNI del array de lectores en columnas de ancho fijo con encabezados (con printf). Añadir un indice a cada lector para que el usuario pueda seleccionar el lector que quiere prestar.
                        System.out.printf("%-10s %-50s %-10s %n", "Índice", "Nombre", "DNI");
                        for (int i = 0; i < lectores.length; i++) {
                            System.out.printf("%-10s %-50s %-10s %n", i, lectores[i].getNombre(), lectores[i].getDNI());
                        }
                        System.out.println("--------------------------------------------------------------------------------");

                        //pedir al usuario que introduzca el índice del lector que quiere prestar
                        System.out.println("Introduzca el índice del lector deseado");
                        int indiceLector = sc.nextInt();

                        //comprobar que ese lector no aparece más de 3 veces en el array de prestamos. Si aparece más de 3 veces, mostrar un mensaje de error y volver al menú. Utilizar While
                        int contador = 0;
                        for (int i = 0; i < prestamos.length; i++) {
                            if (prestamos[i] != null) {
                                if (prestamos[i].getLector().getDNI().equals(lectores[indiceLector].getDNI())) {
                                    contador++;
                                }
                            }
                        }
                        System.out.println("--------------------------------------------------------------------------------");
                        //si el contador es mayor que 2, mostrar un mensaje de error y volver al menú.
                        if (contador > 2) {
                            System.out.println("El lector no puede sacar más libros");
                            System.out.println("Volviendo al menú...");
                            

                        } else {
                            //calcular el número de préstamo
                            int numeroPrestamo = 0;
                            for (Prestamo prestamo : prestamos) {
                                if (prestamo != null) {
                                    numeroPrestamo++;
                                }
                            }

                            //crear un objeto de la clase Prestamo con el libro, el lector y el número de préstamo
                            Prestamo prestamo = new Prestamo(libros[indiceLibro], lectores[indiceLector], numeroPrestamo);

                            //añadir el objeto de la clase Prestamo al primer elemento del array de prestamos que sea null. utilizar un While
                            int contadorPrestamos = 0;
                            while (prestamos[contadorPrestamos] != null) {
                                contadorPrestamos++;
                            }
                            prestamos[contadorPrestamos] = prestamo;

                            //restar 1 al número de ejemplares disponibles del libro prestado
                            libros[indiceLibro].setEjemplaresDisponibles(libros[indiceLibro].getEjemplaresDisponibles() - 1);

                            //imprimir el número de préstamo, el título del libro, el ISBN y el nombre del lector
                            System.out.printf("%-15s %-50s %-15s %-50s %n", "N préstamo", "Título", "ISBN", "Nombre usuario");
                            System.out.printf("%-15s %-50s %-15s %-50s %n", prestamo.getNumeroPrestamo(), prestamo.getLibro().getTitulo(), prestamo.getLibro().getISBN(), prestamo.getLector().getNombre());
                        }
                        
                        
                    } else {
                        System.out.println("El libro no está disponible");
                    }
                }
                case 2 -> {
                    //imprimir el el array de prestamos en columnas de ancho fijo con encabezados (con printf).
                    System.out.printf("%-15s %-50s %-15s %-50s %n", "N préstamo", "Título", "ISBN", "Nombre usuario");
                    for (Prestamo prestamo : prestamos) {
                        if (prestamo != null) {
                            System.out.printf("%-15s %-50s %-15s %-50s %n", prestamo.getNumeroPrestamo(), prestamo.getLibro().getTitulo(), prestamo.getLibro().getISBN(), prestamo.getLector().getNombre());
                        }
                    }
                    
                    //pedir al usuario que introduzca el numeroPrestamo del prestamo que quiere devolver
                    System.out.println("Introduzca el número de préstamo del libro que quiere devolver");
                    int numeroPrestamo = sc.nextInt();
                    
                    //buscar el prestamo en el array de prestamo cuyo numero de prestamo coincide con el numeroPrestamo introducido por el usuario. Utilizar un While
                    int indicePrestamo = 0;
                    while (prestamos[indicePrestamo].getNumeroPrestamo() != numeroPrestamo) {
                        indicePrestamo++;
                    }

                    //buscar el libro en el array de libros cuyo ISBN coincide con el ISBN del libro del prestamo que se quiere devolver. Utilizar un While
                    int indiceLibro = 0;
                    while (!prestamos[indicePrestamo].getLibro().getISBN().equals(libros[indiceLibro].getISBN())) {
                        indiceLibro++;
                    }

                    //sumar 1 al número de ejemplares disponibles del libro
                    libros[indiceLibro].setEjemplaresDisponibles(libros[indiceLibro].getEjemplaresDisponibles() + 1);

                    //eliminar el prestamo del array de prestamos
                    prestamos[indicePrestamo] = null;
                    

                    //imprimir un mensaje de éxito
                    System.out.println("El libro se ha devuelto correctamente");



                }
                case 3 -> {
                    //imprimir el array de prestamos en columnas de ancho fijo con encabezados (con printf).
                    System.out.printf("%-15s %-50s %-15s %-50s %n", "N préstamo", "Título", "ISBN", "Nombre usuario");
                    for (Prestamo prestamo : prestamos) {
                        if (prestamo != null) {
                            System.out.printf("%-15s %-50s %-15s %-50s %n", prestamo.getNumeroPrestamo(), prestamo.getLibro().getTitulo(), prestamo.getLibro().getISBN(), prestamo.getLector().getNombre());
                        }
                    }
                }
                case 4 -> System.out.println("Saliendo...");
                default -> System.out.println("Opción incorrecta");
            }
                    } while (opcion != 4);

    }

    
    
}
